===========
pydown
===========

Pydown is a library for downloading files from the Internet. It also includes a simple textual interface. I have currently written it as my first production use program, so I'm keeping it in a state of perpetual beta until I'm absolutley sure it works. Install it using your preferred method of getting Python packages and then open the interface simply by calling it with no arguments or use its functions in your own code.

Todo list
===========
* Implement a website with information and bugtrackers
* Allow users to pass URLs as command line arguments and have it quickly download them
* Implement a function for compressing downloaded files
* Seperate code into multiple individual Python source files

Changelog
=========
v1.2.1
-------------
* Updated setup.py, the install now requires setuptools or distribute but also now includes a Python Egg

v1.2
-------------
* Added downloading functions, will document in a few days, for now I've commented the code in the source
* Removed unused code files to clean distro

v1.1
-------------
* The main script has been completely rewritten, it now collects all of the info it needs and THEN works on the download
* The package has been revamped, it will now execute properly when called
* Two unused code files, natfun.py and oldCode.py, have been added to the package (they contain some unused functions and the pre 1.1 code, respectively)
* Implemented new packaging structure which began development back in 1.0.1

v1.0.1
-------------
* Updated documentation to remove old mentions of the working name "pyget" and generally clean it up
* Added gzip package, planned to become the only distributed package

v1.0.0
-------------
* Initial release

License
=========

Copyright (c) 2013 Nathan2055
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the software nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE DEVELOPERS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.