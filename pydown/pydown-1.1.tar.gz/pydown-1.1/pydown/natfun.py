# natfun - Nathan2055's function library
def working(text, internals):
    print(text + '...', end='')
    internals
    print('done!')

def pause():
    print('Press enter to continue')
    input()
