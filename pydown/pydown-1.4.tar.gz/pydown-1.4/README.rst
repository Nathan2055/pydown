===========
pydown
===========

Pydown is a library for downloading files from the Internet. It also includes a simple textual interface. Install it using your preferred method of getting Python packages and then open the interface simply by calling it with no arguments (`python -m pydown`) or by using its functions in your own code.

As of version 1.2.1, pydown requires Distribute or setuptools to install.

The bugtracker is available at `https://github.com/Nathan2055/pydown/issues <https://github.com/Nathan2055/pydown/issues>`_. The documentation can be found at `https://github.com/Nathan2055/pydown/wiki <https://github.com/Nathan2055/pydown/wiki>`_.